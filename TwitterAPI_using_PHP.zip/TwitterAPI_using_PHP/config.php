<?php
define('CONSUMER_KEY', 'hBlogfabnqC4PEEfj9afpB0cP');
define('CONSUMER_SECRET', 'RyGbBzrMmgTbOfUjv9jHLCKe77HZ89nD6NnD3KvgBaNhCr1EhF');
define('OAUTH_CALLBACK', 'http://localhost:81/ManiPs/web/twitterAPI/login_with_twitter_using_php/process.php');
?>
